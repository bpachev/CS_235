//Benjamin Pachev CS Fall 235 Midterm
#include "Person.h"
#include "DoubleLinkedList.h"
#include "RedRover.h"
#include "stdio.h"

int main()
{
  RedRover* instance = new RedRover();
  instance->menu();
}