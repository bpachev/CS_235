#include "Arena.h"


#ifdef MAIN
int main()
{
  return 128;
}
#endif